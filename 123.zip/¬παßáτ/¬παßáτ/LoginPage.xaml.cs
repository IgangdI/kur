﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace курсач
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        private int failedAttempts = 0;
        private const int MaxFailedAttempts = 3;
        private bool captchaVerified = false;
        public LoginPage()
        {
            InitializeComponent();
        }
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            var Login = LoginBox.Text.Trim();
            var Password = PasswordBox.Password.Trim();
            var user = ProgBaseEntities.GetContext().USERS.AsEnumerable().FirstOrDefault(u => u.login == Login);

            if (string.IsNullOrEmpty(Login) && string.IsNullOrEmpty(Password))
            {
                MessageBox.Show("Введите логин и пароль!");
                return;
            }
            if (string.IsNullOrEmpty(Login))
            {
                MessageBox.Show("Введите логин!");
                return;
            }
            if (string.IsNullOrEmpty(Password))
            {
                MessageBox.Show("Введите пароль!");
                return;
            }

            if (user == null || user.password != Password)
            {
                failedAttempts++;
                if (failedAttempts >= MaxFailedAttempts)
                {
                    ShowCaptcha();
                }
                MessageBox.Show("Неправильный логин или пароль");
                return;
            }

            // Если логин и пароль верные - пропускаем без капчи
            CompleteLogin();
        }

        private void ShowCaptcha()
        {
            GenerateNewCaptcha();
            CaptchaBorder.Visibility = Visibility.Visible;
            LoginButton.IsEnabled = false;
        }

        private void HideCaptcha()
        {
            CaptchaBorder.Visibility = Visibility.Collapsed;
            LoginButton.IsEnabled = true;
            captchaVerified = true;
        }

        private void GenerateNewCaptcha()
        {
            // Generate a random 6-character captcha
            var random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            CaptchaText.Text = new string(Enumerable.Repeat(chars, 6)
                .Select(s => s[random.Next(s.Length)]).ToArray());
            CaptchaInput.Text = "";
        }

        private void RefreshCaptchaBtn_Click(object sender, RoutedEventArgs e)
        {
            GenerateNewCaptcha();
        }

        private void CaptchaSubmitBtn_Click(object sender, RoutedEventArgs e)
        {
            if (CaptchaInput.Text.Trim().Equals(CaptchaText.Text, StringComparison.OrdinalIgnoreCase))
            {
                // Проверяем логин/пароль снова после успешной капчи
                var Login = LoginBox.Text.Trim();
                var Password = PasswordBox.Password.Trim();
                var user = ProgBaseEntities.GetContext().USERS.AsEnumerable().FirstOrDefault(u => u.login == Login);

                if (user != null && user.password == Password)
                {
                    CompleteLogin();
                }
                else
                {
                    MessageBox.Show("Логин или пароль неверные");
                    HideCaptcha();
                }
            }
            else
            {
                MessageBox.Show("Неверная капча. Попробуйте снова.");
                GenerateNewCaptcha();
            }
        }

        private void CompleteLogin()
        {
            // Reset attempts for next time
            failedAttempts = 0;
            captchaVerified = false;

            // Proceed with login
            Manager.MainFrame.Navigate(new PasswordPage());
        }
        private void LoginBox_GotFocus(object sender, RoutedEventArgs e)
        {
            LoginText.Visibility = Visibility.Collapsed;
        }

        private void LoginBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LoginBox.Text))
                LoginText.Visibility = Visibility.Visible;
        }

        private void PasswordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordText.Visibility = Visibility.Collapsed;
        }

        private void PasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PasswordBox.Password))
                PasswordText.Visibility = Visibility.Visible;
        }
    }
}
